package com.example.cvdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CvdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
