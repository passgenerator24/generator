package com.example.cvuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CvuserApplicationTests {

	@Test
	void contextLoads() {
	}

}
